export default function Features(){
const items=['Cocktails','Gastronomy','Panoramic Views','Private Events'];
return <section><h2>Experiences</h2><div className="grid">
{items.map(i=><div className="card" key={i}>{i}</div>)}
</div></section>
}