'use client'
import {motion} from 'framer-motion';

export default function Hero(){
return <section className="hero">
<motion.div initial={{opacity:0,y:30}} animate={{opacity:1,y:0}}>
<p>DON'T GO TO HEAVEN</p>
<h1>B·HEAVEN GRANADA</h1>
<p>Luxury rooftop dining, cocktails and unforgettable Granada views.</p>
<button>Reserve Table</button>
</motion.div>
</section>
}